// store.js
import { configureStore } from "@reduxjs/toolkit";
import userSlice from "./features/userSlice";
import providersSlice from "./features/providersSlice"
import sessionReducer from "./features/sessionSlice";
import authReducer from "./features/authSlice";

export const store = configureStore({
  reducer: {
    user: userSlice,
    providers: providersSlice,
    session: sessionReducer,
    auth: authReducer,
  },
});

export default store;
