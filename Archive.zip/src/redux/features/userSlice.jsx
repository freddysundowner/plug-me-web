// features/userSlice.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  user: null,
  providers: [],
};

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    updateUser: (state, action) => {
      state.user = action.payload;
    },
    setUser: (state, action) => {
      state.user = action.payload;
    },
    clearUser: (state) => {
      state.user = null;
    },
  },
});

export const { updateUser, setUser, clearUser } =
  userSlice.actions;
export default userSlice.reducer;
