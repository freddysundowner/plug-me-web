// features/userSlice.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  providers: [],
};

const providersSlice = createSlice({
  name: "providers",
  initialState,
  reducers: {
    clearProviders: (state) => {
      state.users = null;
    },
    setProviders: (state, action) => {
      state.providers = action.payload;
    },
  },
});

export const { clearProviders, setProviders } =
  providersSlice.actions;
export default providersSlice.reducer;
